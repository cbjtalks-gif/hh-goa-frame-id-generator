import { createFileRoute } from "@tanstack/react-router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  Download,
  ImageUp,
  RefreshCw,
  RotateCw,
  Share2,
  Shuffle,
  Sparkles,
  ZoomIn,
} from "lucide-react";
import QRCode from "qrcode";
import {
  BADGE_H,
  BADGE_W,
  PFP_SIZE,
  renderBadge,
  renderPfp,
  THEMES,
  type QrMatrix,
  type ThemeKey,
  type Transform,
} from "@/lib/hh-render";
import { ROLE_PRESETS, STICKER_PRESETS, randomTitle } from "@/lib/builder-titles";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "HH Goa 2026 Frame & Builder ID Card Generator" },
      {
        name: "description",
        content:
          "Make your Hacker House Goa 2026 profile frame or Builder ID badge in seconds. Upload, crop, download HD — no signup, all in your browser.",
      },
      { property: "og:title", content: "HH Goa 2026 Frame & Builder ID Card Generator" },
      {
        property: "og:description",
        content:
          "Make your Hacker House Goa 2026 profile frame or Builder ID badge in seconds. Upload, crop, download HD — no signup, all in your browser.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Generator,
});

const SHARE_TEXT =
  "I'm ready for Hacker House Goa 2026! 🚀 Built my custom builder pass. See you at the beach! #FrameInGoa @247PMSTUDIO";

const DEFAULT_T: Transform = { zoom: 1, offsetX: 0, offsetY: 0, rotation: 0 };

const INPUT_CLASS =
  "w-full rounded-xl border-2 border-ink/70 bg-background/0 bg-white px-4 py-3 text-sm font-semibold text-ink outline-none placeholder:text-ink/40 focus:border-pink";

function Generator() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const dragRef = useRef<{ x: number; y: number; ox: number; oy: number } | null>(null);
  const [img, setImg] = useState<HTMLImageElement | null>(null);
  const [mode, setMode] = useState<"pfp" | "badge">("pfp");
  const [t, setT] = useState<Transform>(DEFAULT_T);
  const [name, setName] = useState("");
  const [role, setRole] = useState("Fullstack");
  const [title, setTitle] = useState(() => randomTitle());
  const [stickers, setStickers] = useState<string[]>(["AI Builder"]);
  const [link, setLink] = useState("");
  const [theme, setTheme] = useState<ThemeKey>("cyber");
  const [loading, setLoading] = useState(false);
  const [dragOver, setDragOver] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [dragging, setDragging] = useState(false);

  const qr = useMemo<QrMatrix>(() => {
    const value = link.trim();
    if (!value) return null;
    try {
      const url = /^https?:\/\//i.test(value) ? value : `https://${value}`;
      const m = QRCode.create(url, { errorCorrectionLevel: "M" }).modules;
      return { size: m.size, data: m.data };
    } catch {
      return null;
    }
  }, [link]);

  const dims = useMemo(
    () => (mode === "pfp" ? { w: PFP_SIZE, h: PFP_SIZE } : { w: BADGE_W, h: BADGE_H }),
    [mode],
  );

  const draw = useCallback(
    (canvas: HTMLCanvasElement, scale: number) => {
      const ctx = canvas.getContext("2d");
      if (!ctx) return;
      canvas.width = dims.w * scale;
      canvas.height = dims.h * scale;
      ctx.imageSmoothingQuality = "high";
      if (mode === "pfp") renderPfp(ctx, img, t, scale);
      else renderBadge(ctx, img, t, { name, role, title, stickers, theme, qr }, scale);
    },
    [dims, img, mode, name, role, t, title, stickers, theme, qr],
  );

  useEffect(() => {
    const c = canvasRef.current;
    if (c) draw(c, 1);
  }, [draw]);

  const loadFile = useCallback(async (file: File) => {
    setError(null);
    setLoading(true);
    try {
      let blob: Blob = file;
      const isHeic = /heic|heif/i.test(file.type) || /\.(heic|heif)$/i.test(file.name);
      if (isHeic) {
        const heic2any = (await import("heic2any")).default;
        blob = (await heic2any({ blob: file, toType: "image/jpeg", quality: 0.92 })) as Blob;
      }
      const url = URL.createObjectURL(blob);
      const image = new Image();
      image.onload = () => {
        setImg(image);
        setT(DEFAULT_T);
        setLoading(false);
      };
      image.onerror = () => {
        setError("We couldn't read that image. Try a JPG or PNG.");
        setLoading(false);
      };
      image.src = url;
    } catch {
      setError("We couldn't read that image. Try a JPG or PNG.");
      setLoading(false);
    }
  }, []);

  const onDownload = () => {
    const off = document.createElement("canvas");
    draw(off, 2);
    const link2 = document.createElement("a");
    link2.download = `hh-goa-2026-${mode === "pfp" ? "frame" : "builder-id"}.png`;
    link2.href = off.toDataURL("image/png");
    link2.click();
  };

  const onShare = () => {
    window.open(
      `https://twitter.com/intent/tweet?text=${encodeURIComponent(SHARE_TEXT)}`,
      "_blank",
      "noopener,noreferrer",
    );
  };

  // canvas drag-to-pan (mouse + touch)
  const pointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!img) return;
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
    dragRef.current = { x: e.clientX, y: e.clientY, ox: t.offsetX, oy: t.offsetY };
    setDragging(true);
  };
  const pointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const d = dragRef.current;
    const rect = canvasRef.current?.getBoundingClientRect();
    if (!d || !rect) return;
    e.preventDefault();
    setT((p) => ({
      ...p,
      offsetX: clamp(d.ox + (e.clientX - d.x) / rect.width, -1, 1),
      offsetY: clamp(d.oy + (e.clientY - d.y) / rect.height, -1, 1),
    }));
  };
  const pointerUp = () => {
    dragRef.current = null;
    setDragging(false);
  };

  // wheel / pinch zoom on the canvas
  const wheelRef = useRef<(e: WheelEvent) => void>(() => {});
  wheelRef.current = (e: WheelEvent) => {
    if (!img) return;
    const dy = e.deltaY * (e.deltaMode === 1 ? 16 : e.deltaMode === 2 ? 100 : 1);
    setT((p) => ({ ...p, zoom: clamp(p.zoom * Math.exp(-dy * 0.0015), 0.5, 3) }));
  };
  useEffect(() => {
    const el = canvasRef.current;
    if (!el) return;
    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      wheelRef.current(e);
    };
    el.addEventListener("wheel", onWheel, { passive: false });
    return () => el.removeEventListener("wheel", onWheel);
  }, []);

  const toggleSticker = (s: string) =>
    setStickers((p) => (p.includes(s) ? p.filter((x) => x !== s) : [...p, s].slice(-4)));

  return (
    <main className="min-h-screen">
      {/* Top navigation */}
      <nav className="sticky top-0 z-30 border-b-2 border-primary/30 bg-background/90 backdrop-blur">
        <div className="mx-auto grid w-full max-w-6xl grid-cols-[minmax(0,1fr)_auto] items-center gap-3 px-5 py-3">
          <a href="#top" className="flex min-w-0 items-center gap-2.5">
            <span className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-primary font-display text-sm text-primary-foreground">
              HH
            </span>
            <span className="min-w-0 leading-none">
              <span className="block truncate font-display text-base tracking-wide text-cream">
                HACKER HOUSE
              </span>
              <span className="label-mono block text-accent">GOA · 2026</span>
            </span>
          </a>
          <a
            href="#generator"
            className="shrink-0 rounded-full bg-primary px-4 py-2.5 font-display text-xs tracking-wider text-primary-foreground transition-transform active:scale-95 sm:px-6 sm:text-sm"
          >
            GO TO GENERATOR
          </a>
        </div>
      </nav>

      {/* Hero */}
      <header id="top" className="mx-auto w-full max-w-6xl px-5 pt-12 pb-4 text-center sm:pt-16">
        <p className="label-mono text-primary">#FRAMEINGOA · BUILDER PASS</p>
        <h1 className="mt-5 font-display text-5xl leading-[0.88] tracking-tight text-cream sm:text-7xl lg:text-8xl">
          HACKER HOUSE
          <span className="block text-primary">GOA 2026</span>
        </h1>
        <p className="mx-auto mt-6 inline-flex rounded-full border-2 border-primary bg-primary/10 px-5 py-2 font-mono text-[0.7rem] font-bold tracking-[0.18em] text-primary sm:text-xs">
          GOA, INDIA • 28 - 31 OCT 2026
        </p>
        <p className="mx-auto mt-6 max-w-xl text-sm text-cream/70 sm:text-base">
          Upload a photo, crop it right, and export a beach-ready profile frame or builder
          ID badge. No login. Everything renders in your browser.
        </p>
        <div className="mx-auto mt-8 h-0.5 w-full max-w-3xl bg-cream/15" />
      </header>

      <section
        id="generator"
        className="mx-auto grid w-full max-w-6xl gap-6 px-5 py-10 lg:grid-cols-[minmax(0,1fr)_minmax(0,420px)]"
      >
        {/* Controls */}
        <div className="order-2 space-y-6 lg:order-1">
          <Panel>
            <PanelTitle>1 · Choose your format</PanelTitle>
            <div className="grid grid-cols-2 gap-3">
              <ModeButton
                active={mode === "pfp"}
                onClick={() => setMode("pfp")}
                label="PFP Frame"
                sub="Square overlay"
              />
              <ModeButton
                active={mode === "badge"}
                onClick={() => setMode("badge")}
                label="Builder ID"
                sub="Event badge"
              />
            </div>
          </Panel>

          <Panel>
            <PanelTitle>2 · Your photo</PanelTitle>
            <label
              onDragOver={(e) => {
                e.preventDefault();
                setDragOver(true);
              }}
              onDragLeave={() => setDragOver(false)}
              onDrop={(e) => {
                e.preventDefault();
                setDragOver(false);
                const f = e.dataTransfer.files?.[0];
                if (f) void loadFile(f);
              }}
              className={cn(
                "flex cursor-pointer flex-col items-center justify-center gap-2 rounded-2xl border-2 border-dashed border-ink/35 bg-ink/[0.04] px-4 py-8 text-center transition-colors hover:border-pink",
                dragOver && "border-pink bg-pink/10",
              )}
            >
              <ImageUp className="h-7 w-7 text-pink" />
              <span className="text-sm font-extrabold text-ink">
                {loading ? "Processing…" : "Drop a photo or tap to browse"}
              </span>
              <span className="label-mono text-ink/55">JPG · PNG · HEIC</span>
              <input
                type="file"
                accept="image/*,.heic,.heif"
                className="hidden"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) void loadFile(f);
                }}
              />
            </label>
            {error && <p className="mt-3 text-xs font-bold text-pink">{error}</p>}

            <div className="mt-5 space-y-4">
              <Slider
                icon={<ZoomIn className="h-4 w-4" />}
                label="Zoom"
                value={t.zoom}
                min={0.5}
                max={3}
                step={0.01}
                onChange={(v) => setT((p) => ({ ...p, zoom: v }))}
                display={`${t.zoom.toFixed(2)}x`}
              />
              <Slider
                label="Pan X"
                value={t.offsetX}
                min={-1}
                max={1}
                step={0.01}
                onChange={(v) => setT((p) => ({ ...p, offsetX: v }))}
                display={t.offsetX.toFixed(2)}
              />
              <Slider
                label="Pan Y"
                value={t.offsetY}
                min={-1}
                max={1}
                step={0.01}
                onChange={(v) => setT((p) => ({ ...p, offsetY: v }))}
                display={t.offsetY.toFixed(2)}
              />
              <Slider
                icon={<RotateCw className="h-4 w-4" />}
                label="Rotate"
                value={t.rotation}
                min={-180}
                max={180}
                step={1}
                onChange={(v) => setT((p) => ({ ...p, rotation: v }))}
                display={`${Math.round(t.rotation)}°`}
              />
              <button
                type="button"
                onClick={() => setT(DEFAULT_T)}
                className="inline-flex items-center gap-2 rounded-full border-2 border-ink/30 px-3.5 py-2 text-xs font-bold text-ink/70 transition-colors hover:border-pink hover:text-pink"
              >
                <RefreshCw className="h-3.5 w-3.5" /> Reset adjustments
              </button>
            </div>
          </Panel>

          {mode === "badge" && (
            <Panel>
              <PanelTitle>3 · Badge details</PanelTitle>
              <div className="space-y-4">
                <Field label="Full name">
                  <input
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Ada Lovelace"
                    maxLength={28}
                    className={INPUT_CLASS}
                  />
                </Field>
                <Field label="Role / tech stack">
                  <input
                    value={role}
                    onChange={(e) => setRole(e.target.value)}
                    placeholder="Fullstack"
                    maxLength={30}
                    className={INPUT_CLASS}
                  />
                  <div className="mt-3 flex flex-wrap gap-2">
                    {ROLE_PRESETS.map((r) => (
                      <Chip key={r} active={role === r} onClick={() => setRole(r)}>
                        {r}
                      </Chip>
                    ))}
                  </div>
                </Field>
                <Field label="Builder title">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="min-w-0 flex-1 rounded-xl border-2 border-pink bg-pink/10 px-4 py-3 text-sm font-extrabold text-ink">
                      {title}
                    </span>
                    <button
                      type="button"
                      onClick={() => setTitle((c) => randomTitle(c))}
                      className="inline-flex shrink-0 items-center gap-2 rounded-xl bg-pink px-4 py-3 text-xs font-extrabold tracking-wide text-cream transition-transform active:scale-95"
                    >
                      <Shuffle className="h-4 w-4" /> REROLL
                    </button>
                  </div>
                </Field>
                <Field label="Portfolio / GitHub URL (optional)">
                  <input
                    value={link}
                    onChange={(e) => setLink(e.target.value)}
                    placeholder="github.com/yourname"
                    inputMode="url"
                    maxLength={120}
                    className={INPUT_CLASS}
                  />
                  <p className="mt-2 text-xs font-medium text-ink/60">
                    {qr
                      ? "A scannable QR code shows on the bottom corner of your card."
                      : "Add a link and we'll drop a QR code on your badge."}
                  </p>
                </Field>
              </div>
            </Panel>
          )}

          {mode === "badge" && (
            <Panel>
              <PanelTitle>4 · Card theme</PanelTitle>
              <div className="grid gap-3 sm:grid-cols-3">
                {(Object.keys(THEMES) as ThemeKey[]).map((k) => {
                  const th = THEMES[k];
                  const on = theme === k;
                  return (
                    <button
                      key={k}
                      type="button"
                      aria-pressed={on}
                      onClick={() => setTheme(k)}
                      className={cn(
                        "rounded-2xl border-2 p-3 text-left transition-all",
                        on
                          ? "border-pink bg-pink/10 shadow-[4px_4px_0_0_var(--accent)]"
                          : "border-ink/25 hover:border-ink/60",
                      )}
                    >
                      <span className="mb-2 flex gap-1">
                        {th.swatch.map((c) => (
                          <span
                            key={c}
                            className="h-4 w-4 rounded-full border border-ink/20"
                            style={{ backgroundColor: c }}
                          />
                        ))}
                      </span>
                      <span className="block text-sm font-extrabold text-ink">
                        {th.label}
                      </span>
                      <span className="block text-xs text-ink/60">{th.sub}</span>
                    </button>
                  );
                })}
              </div>
            </Panel>
          )}

          {mode === "badge" && (
            <Panel>
              <PanelTitle>5 · Badges &amp; stickers</PanelTitle>
              <p className="mb-3 text-xs font-medium text-ink/60">
                Tap to toggle — up to 4 show on your ID card.
              </p>
              <div className="flex flex-wrap gap-2">
                {STICKER_PRESETS.map((s) => (
                  <Chip
                    key={s}
                    active={stickers.includes(s)}
                    onClick={() => toggleSticker(s)}
                  >
                    {s}
                  </Chip>
                ))}
              </div>
              {stickers.length > 0 && (
                <button
                  type="button"
                  onClick={() => setStickers([])}
                  className="mt-4 inline-flex items-center gap-2 rounded-full border-2 border-ink/30 px-3.5 py-2 text-xs font-bold text-ink/70 transition-colors hover:border-pink hover:text-pink"
                >
                  Clear stickers
                </button>
              )}
            </Panel>
          )}
        </div>

        {/* Preview */}
        <div className="order-1 lg:order-2">
          <div className="lg:sticky lg:top-24">
            <div className="paper-card-pink p-4">
              <div className="mb-3 flex items-center gap-2">
                <Sparkles className="h-3.5 w-3.5 text-pink" />
                <span className="label-mono text-ink/70">Live preview</span>
              </div>
              <canvas
                ref={canvasRef}
                onPointerDown={pointerDown}
                onPointerMove={pointerMove}
                onPointerUp={pointerUp}
                onPointerCancel={pointerUp}
                style={{ aspectRatio: `${dims.w} / ${dims.h}` }}
                className={cn(
                  "w-full touch-none rounded-xl border-2 border-ink/80 bg-emerald-deep",
                  img ? (dragging ? "cursor-grabbing" : "cursor-grab") : "cursor-default",
                )}
              />
              <p className="mt-2 text-center text-[11px] font-medium text-ink/60">
                Drag the photo to reposition · scroll or pinch to zoom
              </p>
              <div className="mt-4 grid gap-3">
                <button
                  type="button"
                  onClick={onDownload}
                  className="inline-flex items-center justify-center gap-2 rounded-full border-2 border-ink bg-primary px-5 py-3.5 font-display text-sm tracking-wide text-ink transition-transform active:scale-[0.98]"
                >
                  <Download className="h-4 w-4" /> DOWNLOAD HD IMAGE
                </button>
                <button
                  type="button"
                  onClick={onShare}
                  className="inline-flex items-center justify-center gap-2 rounded-full border-2 border-ink bg-pink px-5 py-3.5 font-display text-sm tracking-wide text-cream transition-transform active:scale-[0.98]"
                >
                  <Share2 className="h-4 w-4" /> SHARE ON X
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      <footer className="border-t-2 border-cream/10">
        <div className="mx-auto w-full max-w-6xl px-5 py-10 text-center">
          <p className="font-display text-2xl text-cream sm:text-3xl">
            LESS NOISE. <span className="text-primary">MORE SIGNAL.</span>
          </p>
          <p className="label-mono mt-3 text-cream/50">
            Built for Hacker House Goa 2026 · #FrameInGoa · 100% in your browser
          </p>
        </div>
      </footer>
    </main>
  );
}

function clamp(v: number, min: number, max: number) {
  return Math.min(max, Math.max(min, v));
}

function Panel({ children }: { children: React.ReactNode }) {
  return <div className="paper-card p-5 sm:p-6">{children}</div>;
}

function PanelTitle({ children }: { children: React.ReactNode }) {
  return (
    <h2 className="mb-4 flex items-center gap-3">
      <span className="label-mono text-pink">{String(children).toUpperCase()}</span>
      <span className="h-0.5 flex-1 bg-ink/15" />
    </h2>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <p className="label-mono mb-2 text-ink/60">{label}</p>
      {children}
    </div>
  );
}

function Chip({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      aria-pressed={active}
      onClick={onClick}
      className={cn(
        "rounded-full border-2 px-3.5 py-1.5 text-xs font-extrabold transition-colors",
        active
          ? "border-ink bg-primary text-ink"
          : "border-ink/25 text-ink/70 hover:border-ink hover:text-ink",
      )}
    >
      {children}
    </button>
  );
}

function ModeButton({
  active,
  onClick,
  label,
  sub,
}: {
  active: boolean;
  onClick: () => void;
  label: string;
  sub: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "rounded-2xl border-2 p-4 text-left transition-all",
        active
          ? "border-ink bg-primary text-ink shadow-[4px_4px_0_0_var(--ink)]"
          : "border-ink/25 text-ink/70 hover:border-ink",
      )}
    >
      <span className="block font-display text-lg tracking-wide">{label}</span>
      <span className={cn("label-mono block", active ? "text-ink/70" : "text-ink/50")}>
        {sub}
      </span>
    </button>
  );
}

function Slider({
  label,
  value,
  min,
  max,
  step,
  onChange,
  display,
  icon,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  onChange: (v: number) => void;
  display: string;
  icon?: React.ReactNode;
}) {
  return (
    <div>
      <div className="mb-1.5 flex items-center justify-between">
        <span className="label-mono inline-flex items-center gap-1.5 text-ink/60">
          {icon}
          {label}
        </span>
        <span className="font-mono text-xs font-bold text-pink">{display}</span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="h-1.5 w-full cursor-pointer appearance-none rounded-full bg-ink/20 accent-pink"
      />
    </div>
  );
}
