export const BUILDER_TITLES = [
  "Goa Code Alchemist",
  "Kernel Surfer",
  "0x Goa Legend",
  "Beachside Bug Slayer",
  "Sunset Shipper",
  "Palm Tree Pipeline Wizard",
  "Latency Lifeguard",
  "Feni-Fueled Refactorer",
  "Tide Table Tinkerer",
  "Midnight Merge Master",
  "Susegad Systems Architect",
  "Prompt Pirate of Anjuna",
  "Coastal Cache Warmer",
  "Sandbox Sandcastle Builder",
  "Monsoon Model Trainer",
  "Vindaloo Vector Hunter",
  "Deploy-at-Dawn Daredevil",
  "Shoreline Shell Scripter",
  "Neon Coconut Hacker",
  "Zero-Downtime Dreamer",
];

export const ROLE_PRESETS = [
  "Fullstack",
  "Frontend",
  "Backend",
  "AI / ML",
  "Security",
  "Web3",
  "Design",
  "DevOps",
];

export function randomTitle(exclude?: string) {
  const pool = BUILDER_TITLES.filter((t) => t !== exclude);
  return pool[Math.floor(Math.random() * pool.length)] ?? BUILDER_TITLES[0]!;
}

export const STICKER_PRESETS = [
  "AI Builder",
  "Security Specialist",
  "Open Source Contributor",
  "First Hackathon",
  "Designer",
  "Web3 Native",
  "Hardware Hacker",
  "Night Owl",
];
