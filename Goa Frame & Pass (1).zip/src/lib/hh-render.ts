export type Transform = {
  zoom: number;
  offsetX: number; // -1..1 relative to frame width
  offsetY: number;
  rotation: number; // degrees
};

export type QrMatrix = { size: number; data: Uint8Array | number[] } | null;

export type ThemeKey = "sunset" | "cyber" | "midnight";

export type BadgeFields = {
  name: string;
  role: string;
  title: string;
  stickers?: string[];
  theme?: ThemeKey;
  qr?: QrMatrix;
};

export const THEMES: Record<
  ThemeKey,
  {
    label: string;
    sub: string;
    bg: [string, string, string];
    glow: string;
    grid: string;
    border: string;
    chip: string;
    accent: string;
    swatch: [string, string, string];
  }
> = {
  sunset: {
    label: "Sunset Goa",
    sub: "Warm coastal dusk",
    bg: ["#3B1030", "#7A1F3D", "#2A0A26"],
    glow: "rgba(255,168,64,0.35)",
    grid: "rgba(255,196,120,0.08)",
    border: "#FFB65C",
    chip: "#FF2E93",
    accent: "#FFD79A",
    swatch: ["#7A1F3D", "#FFB65C", "#FF2E93"],
  },
  cyber: {
    label: "Cyberpunk Emerald",
    sub: "Classic HH Goa",
    bg: ["#00251B", "#003A2B", "#001A13"],
    glow: "rgba(255,46,147,0.28)",
    grid: "rgba(255,238,88,0.07)",
    border: "#FFEE58",
    chip: "#FF2E93",
    accent: "#FFEE58",
    swatch: ["#003A2B", "#FFEE58", "#FF2E93"],
  },
  midnight: {
    label: "Neon Midnight",
    sub: "Deep violet night",
    bg: ["#0B0A2A", "#161045", "#05041A"],
    glow: "rgba(0,229,255,0.3)",
    grid: "rgba(0,229,255,0.08)",
    border: "#00E5FF",
    chip: "#B14BFF",
    accent: "#00E5FF",
    swatch: ["#0B0A2A", "#00E5FF", "#B14BFF"],
  },
};

export const COLORS = {
  emerald: "#003A2B",
  emeraldDeep: "#00201800",
  ink: "#001710",
  yellow: "#FFEE58",
  pink: "#FF2E93",
  white: "#FFFFFF",
};

export const PFP_SIZE = 1080;
export const BADGE_W = 900;
export const BADGE_H = 1350;

const DISPLAY = '"Anton", "Archivo Black", system-ui, sans-serif';
const BODY = '"Plus Jakarta Sans", system-ui, sans-serif';

function roundRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number,
) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

function drawPhoto(
  ctx: CanvasRenderingContext2D,
  img: HTMLImageElement | null,
  x: number,
  y: number,
  w: number,
  h: number,
  t: Transform,
) {
  ctx.save();
  ctx.beginPath();
  ctx.rect(x, y, w, h);
  ctx.clip();

  if (!img) {
    const g = ctx.createLinearGradient(x, y, x + w, y + h);
    g.addColorStop(0, "#012A20");
    g.addColorStop(1, "#004433");
    ctx.fillStyle = g;
    ctx.fillRect(x, y, w, h);
    ctx.fillStyle = "rgba(255,255,255,0.35)";
    ctx.font = `600 ${Math.round(w * 0.05)}px ${BODY}`;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText("Upload a photo", x + w / 2, y + h / 2);
    ctx.restore();
    return;
  }

  const cx = x + w / 2 + t.offsetX * w;
  const cy = y + h / 2 + t.offsetY * h;
  ctx.translate(cx, cy);
  ctx.rotate((t.rotation * Math.PI) / 180);

  const cover = Math.max(w / img.width, h / img.height) * t.zoom;
  const dw = img.width * cover;
  const dh = img.height * cover;
  ctx.drawImage(img, -dw / 2, -dh / 2, dw, dh);
  ctx.restore();
}

function fitText(
  ctx: CanvasRenderingContext2D,
  text: string,
  maxWidth: number,
  weight: string,
  startSize: number,
  family: string,
  minSize = 18,
) {
  let size = startSize;
  ctx.font = `${weight} ${size}px ${family}`;
  while (ctx.measureText(text).width > maxWidth && size > minSize) {
    size -= 2;
    ctx.font = `${weight} ${size}px ${family}`;
  }
  return size;
}

function grid(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  step: number,
  color = "rgba(255,238,88,0.07)",
) {
  ctx.save();
  ctx.strokeStyle = color;
  ctx.lineWidth = 2;
  for (let x = 0; x <= w; x += step) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, h);
    ctx.stroke();
  }
  for (let y = 0; y <= h; y += step) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(w, y);
    ctx.stroke();
  }
  ctx.restore();
}

export function renderPfp(
  ctx: CanvasRenderingContext2D,
  img: HTMLImageElement | null,
  t: Transform,
  scale = 1,
) {
  const S = PFP_SIZE * scale;
  ctx.save();
  ctx.clearRect(0, 0, S, S);
  ctx.fillStyle = COLORS.emerald;
  ctx.fillRect(0, 0, S, S);

  const pad = 0;
  drawPhoto(ctx, img, pad, pad, S - pad * 2, S - pad * 2, t);

  // bottom gradient scrim
  const g = ctx.createLinearGradient(0, S * 0.5, 0, S);
  g.addColorStop(0, "rgba(0,32,24,0)");
  g.addColorStop(1, "rgba(0,32,24,0.95)");
  ctx.fillStyle = g;
  ctx.fillRect(0, S * 0.5, S, S * 0.5);

  // top scrim
  const g2 = ctx.createLinearGradient(0, 0, 0, S * 0.3);
  g2.addColorStop(0, "rgba(0,32,24,0.75)");
  g2.addColorStop(1, "rgba(0,32,24,0)");
  ctx.fillStyle = g2;
  ctx.fillRect(0, 0, S, S * 0.3);

  // frame border
  const b = S * 0.028;
  ctx.strokeStyle = COLORS.yellow;
  ctx.lineWidth = b;
  ctx.strokeRect(b / 2, b / 2, S - b, S - b);
  ctx.strokeStyle = COLORS.pink;
  ctx.lineWidth = b * 0.35;
  ctx.strokeRect(b * 1.7, b * 1.7, S - b * 3.4, S - b * 3.4);

  // corner ticks
  ctx.fillStyle = COLORS.pink;
  const tick = S * 0.09;
  ctx.fillRect(b, b, tick, b * 0.9);
  ctx.fillRect(S - b - tick, S - b - b * 0.9, tick, b * 0.9);

  // top label
  ctx.textBaseline = "middle";
  ctx.textAlign = "left";
  ctx.fillStyle = COLORS.yellow;
  ctx.font = `700 ${S * 0.028}px ${BODY}`;
  ctx.letterSpacing = `${S * 0.006}px`;
  ctx.fillText("HACKER HOUSE", S * 0.075, S * 0.085);
  ctx.fillStyle = COLORS.white;
  ctx.textAlign = "right";
  ctx.fillText("#FRAMEINGOA", S - S * 0.075, S * 0.085);

  // bottom lockup
  ctx.textAlign = "left";
  ctx.letterSpacing = "0px";
  ctx.fillStyle = COLORS.white;
  ctx.font = `900 ${S * 0.105}px ${DISPLAY}`;
  ctx.fillText("GOA", S * 0.075, S - S * 0.155);
  const goaW = ctx.measureText("GOA").width;
  ctx.fillStyle = COLORS.yellow;
  ctx.fillText("2026", S * 0.075 + goaW + S * 0.025, S - S * 0.155);

  ctx.fillStyle = COLORS.pink;
  ctx.fillRect(S * 0.075, S - S * 0.098, S * 0.09, S * 0.008);

  ctx.fillStyle = "rgba(255,255,255,0.85)";
  ctx.font = `600 ${S * 0.03}px ${BODY}`;
  ctx.letterSpacing = `${S * 0.004}px`;
  ctx.fillText("GOA, INDIA • 28-31 OCT 2026", S * 0.075, S - S * 0.06);
  ctx.letterSpacing = "0px";
  ctx.restore();
}

function drawQr(
  ctx: CanvasRenderingContext2D,
  qr: NonNullable<QrMatrix>,
  x: number,
  y: number,
  size: number,
  quiet: number,
) {
  ctx.save();
  ctx.fillStyle = "#FFFFFF";
  roundRect(ctx, x, y, size, size, quiet);
  ctx.fill();
  const inner = size - quiet * 2;
  const cell = inner / qr.size;
  ctx.fillStyle = "#04120D";
  for (let r = 0; r < qr.size; r++) {
    for (let c = 0; c < qr.size; c++) {
      if (qr.data[r * qr.size + c]) {
        ctx.fillRect(
          x + quiet + c * cell,
          y + quiet + r * cell,
          Math.ceil(cell),
          Math.ceil(cell),
        );
      }
    }
  }
  ctx.restore();
}

export function renderBadge(
  ctx: CanvasRenderingContext2D,
  img: HTMLImageElement | null,
  t: Transform,
  f: BadgeFields,
  scale = 1,
) {
  const W = BADGE_W * scale;
  const H = BADGE_H * scale;
  const u = W / 900; // unit
  const th = THEMES[f.theme ?? "cyber"];
  ctx.save();
  ctx.clearRect(0, 0, W, H);

  const bg = ctx.createLinearGradient(0, 0, W, H);
  bg.addColorStop(0, th.bg[0]);
  bg.addColorStop(0.55, th.bg[1]);
  bg.addColorStop(1, th.bg[2]);
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, W, H);
  grid(ctx, W, H, 60 * u, th.grid);

  // accent glow
  const glow = ctx.createRadialGradient(W, 0, 0, W, 0, W * 0.9);
  glow.addColorStop(0, th.glow);
  glow.addColorStop(1, "rgba(0,0,0,0)");
  ctx.fillStyle = glow;
  ctx.fillRect(0, 0, W, H);

  // outer border
  ctx.strokeStyle = th.border;
  ctx.lineWidth = 10 * u;
  ctx.strokeRect(5 * u, 5 * u, W - 10 * u, H - 10 * u);

  const M = 64 * u;

  // header
  ctx.textBaseline = "middle";
  ctx.textAlign = "left";
  ctx.fillStyle = th.border;
  roundRect(ctx, M, 62 * u, 74 * u, 74 * u, 18 * u);
  ctx.fill();
  ctx.fillStyle = th.bg[2];
  ctx.font = `900 ${34 * u}px ${DISPLAY}`;
  ctx.textAlign = "center";
  ctx.fillText("HH", M + 37 * u, 101 * u);

  ctx.textAlign = "left";
  ctx.fillStyle = COLORS.white;
  ctx.font = `900 ${34 * u}px ${DISPLAY}`;
  ctx.fillText("HACKER HOUSE", M + 96 * u, 88 * u);
  ctx.fillStyle = th.chip;
  ctx.font = `700 ${24 * u}px ${BODY}`;
  ctx.letterSpacing = `${3 * u}px`;
  ctx.fillText("GOA · 2026", M + 96 * u, 120 * u);
  ctx.letterSpacing = "0px";

  // photo panel
  const px = M;
  const py = 176 * u;
  const pw = W - M * 2;
  const ph = 520 * u;
  ctx.save();
  roundRect(ctx, px, py, pw, ph, 26 * u);
  ctx.clip();
  drawPhoto(ctx, img, px, py, pw, ph, t);
  const scrim = ctx.createLinearGradient(0, py + ph * 0.55, 0, py + ph);
  scrim.addColorStop(0, "rgba(0,0,0,0)");
  scrim.addColorStop(1, "rgba(0,0,0,0.78)");
  ctx.fillStyle = scrim;
  ctx.fillRect(px, py, pw, ph);
  ctx.restore();
  roundRect(ctx, px, py, pw, ph, 26 * u);
  ctx.strokeStyle = th.border;
  ctx.lineWidth = 5 * u;
  ctx.stroke();

  // builder title chip on photo
  const title = (f.title || "").toUpperCase();
  ctx.font = `800 ${26 * u}px ${BODY}`;
  const tw = ctx.measureText(title).width;
  const chipW = Math.min(tw + 44 * u, pw - 48 * u);
  ctx.fillStyle = th.chip;
  roundRect(ctx, px + 24 * u, py + ph - 84 * u, chipW, 56 * u, 28 * u);
  ctx.fill();
  ctx.fillStyle = COLORS.white;
  ctx.textAlign = "center";
  ctx.fillText(title, px + 24 * u + chipW / 2, py + ph - 55 * u);

  // sticker chips above the title chip
  const stickers = (f.stickers ?? []).filter(Boolean);
  if (stickers.length) {
    ctx.textAlign = "left";
    ctx.font = `800 ${21 * u}px ${BODY}`;
    const gap = 12 * u;
    const chipH = 44 * u;
    const maxW = pw - 48 * u;
    const rows: { label: string; w: number }[][] = [[]];
    let rowW = 0;
    for (const s of stickers) {
      const label = s.toUpperCase();
      const w = ctx.measureText(label).width + 34 * u;
      if (rowW + w > maxW && rows[rows.length - 1]!.length) {
        rows.push([]);
        rowW = 0;
      }
      rows[rows.length - 1]!.push({ label, w });
      rowW += w + gap;
    }
    const shown = rows.slice(-2);
    let cy2 = py + ph - 108 * u - shown.length * (chipH + gap) + gap;
    for (const row of shown) {
      let cx2 = px + 24 * u;
      for (const chip of row) {
        ctx.fillStyle = "rgba(0,0,0,0.55)";
        roundRect(ctx, cx2, cy2, chip.w, chipH, chipH / 2);
        ctx.fill();
        ctx.strokeStyle = th.accent;
        ctx.lineWidth = 3 * u;
        roundRect(ctx, cx2, cy2, chip.w, chipH, chipH / 2);
        ctx.stroke();
        ctx.fillStyle = th.accent;
        ctx.textAlign = "center";
        ctx.fillText(chip.label, cx2 + chip.w / 2, cy2 + chipH / 2 + 1 * u);
        ctx.textAlign = "left";
        cx2 += chip.w + gap;
      }
      cy2 += chipH + gap;
    }
  }

  const qr = f.qr ?? null;
  const qrSize = 190 * u;
  const textW = qr ? pw - qrSize - 30 * u : pw;

  // name
  ctx.textAlign = "left";
  const name = (f.name || "YOUR NAME").toUpperCase();
  const nameSize = fitText(ctx, name, textW, "900", 74 * u, DISPLAY, 30 * u);
  ctx.fillStyle = COLORS.white;
  ctx.font = `900 ${nameSize}px ${DISPLAY}`;
  ctx.fillText(name, M, 780 * u);

  // role
  ctx.fillStyle = th.accent;
  ctx.font = `700 ${30 * u}px ${BODY}`;
  ctx.letterSpacing = `${2 * u}px`;
  ctx.fillText((f.role || "BUILDER").toUpperCase(), M, 838 * u);
  ctx.letterSpacing = "0px";

  // divider
  ctx.strokeStyle = "rgba(255,255,255,0.18)";
  ctx.lineWidth = 3 * u;
  ctx.beginPath();
  ctx.moveTo(M, 884 * u);
  ctx.lineTo(W - M, 884 * u);
  ctx.stroke();

  // meta rows
  const rows: [string, string][] = [
    ["BUILDER TITLE", f.title || "—"],
    ["ACCESS", "ALL AREAS · HACK · SHIP"],
    ["WHERE & WHEN", "GOA, INDIA • 28-31 OCT 2026"],
  ];
  rows.forEach(([k, v], i) => {
    const y = 936 * u + i * 78 * u;
    ctx.fillStyle = "rgba(255,255,255,0.55)";
    ctx.font = `700 ${20 * u}px ${BODY}`;
    ctx.letterSpacing = `${2 * u}px`;
    ctx.fillText(k, M, y);
    ctx.letterSpacing = "0px";
    ctx.fillStyle = COLORS.white;
    const vs = fitText(ctx, v, textW, "800", 30 * u, BODY, 18 * u);
    ctx.font = `800 ${vs}px ${BODY}`;
    ctx.fillText(v, M, y + 34 * u);
  });

  // QR code (bottom-right corner)
  if (qr) {
    const qx = W - M - qrSize;
    const qy = 926 * u;
    drawQr(ctx, qr, qx, qy, qrSize, 10 * u);
    ctx.fillStyle = th.accent;
    ctx.font = `700 ${17 * u}px ${BODY}`;
    ctx.textAlign = "center";
    ctx.letterSpacing = `${2 * u}px`;
    ctx.fillText("SCAN ME", qx + qrSize / 2, qy + qrSize + 20 * u);
    ctx.letterSpacing = "0px";
    ctx.textAlign = "left";
  }

  // barcode footer
  const by = H - 118 * u;
  ctx.fillStyle = th.border;
  ctx.fillRect(M, by, pw, 4 * u);
  let bx = M;
  const seed = (f.name || "goa").length + (f.role || "").length + 7;
  for (let i = 0; bx < W - M - 260 * u; i++) {
    const bw = ((seed * (i + 3)) % 5) * 2 * u + 3 * u;
    ctx.fillStyle = i % 2 === 0 ? COLORS.white : "rgba(255,255,255,0.25)";
    ctx.fillRect(bx, by + 22 * u, bw, 44 * u);
    bx += bw + 6 * u;
  }
  ctx.fillStyle = th.chip;
  ctx.font = `800 ${24 * u}px ${BODY}`;
  ctx.textAlign = "right";
  ctx.fillText("#FRAMEINGOA", W - M, by + 44 * u);
  ctx.restore();
}
