# HH Goa 2026 Frame & Builder ID Card Generator

A single-page, no-login tool where a visitor uploads a photo, adjusts it on a live canvas, and exports either a branded PFP frame or a Builder ID badge — all rendered in the browser, no server round-trips.

## Flow

```text
Upload photo  ->  Adjust (zoom / pan / rotate)  ->  Pick mode
                                                     |- PFP Frame
                                                     |- Builder ID Card (name, role, auto title)
                                                   ->  Live canvas preview
                                                   ->  Download PNG  |  Share on X
```

## What gets built

1. Hero + single-column workflow on `/` (replaces the placeholder page): headline, short pitch, event dateline "GOA, INDIA - 28-31 OCT 2026".
2. Upload zone: drag-and-drop plus file button, accepts JPG, PNG, HEIC (HEIC converted in-browser to a usable image before editing).
3. Adjust controls: zoom slider, X/Y pan sliders (and drag on the canvas), rotation slider, reset button. Any source aspect ratio is handled by cover-fitting into the square/badge crop.
4. Mode toggle:
   - PFP Frame: square 1080x1080 export with the HH Goa 2026 frame ring, event wordmark, and dateline drawn over the photo.
   - Builder ID Card: portrait badge export with logo, photo cutout, Full Name field, Role/Tech Stack field (preset chips plus free text), an auto-generated Builder Title with a "reroll" button, and the dateline.
5. Live rendering: every keystroke and control change redraws the canvas immediately.
6. Actions: "Download HD Image" (2x-resolution PNG) and "Share on X" opening the intent URL with the specified caption.

## Design

- Dark emerald base (#003A2B) with deep near-black gradients, cyber yellow (#FFEE58) as the primary action/heading accent, bright pink (#FF2E93) for secondary accents and glow, white for body text.
- Bold condensed-feel display headings paired with Plus Jakarta Sans body text, loaded via a font link in the root route.
- Grain/glow coastal-tech texture, chunky bordered cards, subtle hover and press motion. All colors as semantic tokens in `src/styles.css` — no hardcoded color classes in components.
- Mobile-first: stacked layout, canvas scales to viewport width, thumb-friendly controls; two-column (controls | preview) from large screens.

## Technical notes

- Pure client-side: native HTML5 Canvas 2D drawing (no fabric.js/html2canvas needed), rendered in a `useEffect` keyed on all state, drawn at export resolution and downscaled via CSS for the preview.
- Photo state: `HTMLImageElement` + `{zoom, offsetX, offsetY, rotation}`; canvas draw applies translate/rotate/scale around the crop center.
- HEIC handled with `heic2any` (dynamically imported client-side only, so SSR is untouched).
- Builder titles come from a local array of Goa/hacker-flavoured names, picked at random with reroll.
- Frame/badge artwork is drawn programmatically (shapes, strokes, text) rather than as image assets, so exports stay crisp at any size.
- Export via `canvas.toDataURL("image/png")` + anchor download.
- Route-level `head()` with app-specific title, description, og/twitter tags.
